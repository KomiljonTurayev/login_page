import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.blueAccent,
        appBar: AppBar(
          title: Text("Salom g'ildirak"),
          backgroundColor: Colors.blue[500],
        ),
        body: Center(
          child: Image(
            image: AssetImage('assets/images/road.jpg'),
          ),
        ),
      ),
    ),
  );
}
